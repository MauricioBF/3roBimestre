--bd teste 3 de 
CREATE TABLE "departamento"(
	"codigo" integer,
	"nome" varchar(100) NOT NULL,
	CONSTRAINT "DepartamentoPK" PRIMARY KEY ("codigo"));

CREATE TABLE "disciplina"(
	"codigo" serial,
	"nome" varchar(100) NOT NULL,
	"cargahoraria" integer NOT NULL,
	"coddepartamento" integer,
	CONSTRAINT "DisciplinaPK" PRIMARY KEY ("codigo"));

INSERT INTO "departamento" ("codigo", "nome") VALUES 
(1,'Ciências'), (2,'Linguagens'), (3,'Gestão'), (4,'Computação');

INSERT INTO "disciplina" ("nome",  "cargahoraria", "coddepartamento") VALUES 
('Matemática Discreta', 60, 1), 
('Fundamentos de Matemática', 60, 1), 
('Programação I', 80, 4),
('Matemática I', 80, 1), 
('Inglês III', 20, 4), 
('Empreendedorismo', 40, 4), 
('Matemática II', 60, 1), 
('Introdução a Computação', 40, 4), 
('Eletrônica I', 100, 4),
('Teoria Geral da Administração', 80, 3),
('Introdução à Economia', 40, 3),
('Cálculo I', 100, 1);
