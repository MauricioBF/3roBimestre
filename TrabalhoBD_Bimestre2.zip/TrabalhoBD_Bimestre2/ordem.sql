1. Altere a tabela disciplina adicionando uma chave estrangeira para departamento no campo codDepartamento. Considere que Disciplina pode não estar vinculada a um departamento. Caso um departamento tenha seu código alterado, esse código será alterado nas linhas de disciplinas também, já se um departamento for excluído, as disciplinas que referenciavam esse departamento, deixaram de fazer referencia a um departamento.


2. Faça uma consulta que retorne as disciplinas (nome e cargaHoraria) com nome começando com “Matematéma” (exemplo: “Matemática I”, “Matemática Discreta”) e com cargaHoraria enre 60 e 100 horas semanais. Ordene sua resposta pela cargaHoraria decrescente.


3. Faça uma consulta que retorne o codDepartamento, a soma de cargaHoraria e a média de cargaHoraria por cada departamento que tiver mais que 2 disciplinas.


4. Insira um departamento de nome “Direção geral” com código 0, após altere todas as disciplinas sem departamento para o departamento “Direção Geral”.