--Exercício 1

    --INSERT INTO "disciplina" ("nome",  "cargahoraria", "coddepartamento") VALUES  ('Teoria Geral dos Cabeça de Teta', 80, 2), ('Introdução à Trocadilhos', 40, 2);

    --UPDATE "departamento" SET "codigo" = 7 WHERE "codigo" = 2;

    --DELETE FROM "departamento" WHERE "codigo" = 7;

    ALTER TABLE "disciplina" ADD CONSTRAINT "DisciplinaFK" FOREIGN KEY ("coddepartamento") REFERENCES "departamento" ("codigo") ON DELETE SET NULL ON UPDATE CASCADE

--Exercício 2

    SELECT "nome", "cargahoraria" FROM "disciplina" WHERE "nome" like '%Matemática_%' and "cargahoraria" between 60 and 100 ORDER BY "cargahoraria" desc

--Exercício 3

    SELECT "coddepartamento", sum("cargahoraria") as "soma", avg("cargahoraria") as "media" FROM "disciplina" GROUP BY "coddepartamento" HAVING count(*)>2

--Exercício 4

    INSERT INTO "departamento" ("codigo", "nome")VALUES (0,'Direção geral');

    UPDATE "disciplina" SET "coddepartamento" = 0 WHERE "coddepartamento" is null