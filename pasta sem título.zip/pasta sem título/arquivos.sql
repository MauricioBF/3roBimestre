--Retorna a data (YYYY/DD/MM) e o horário atual (HH:MM:SS:mmmmmm-mm)
SELECT NOW()

--Retorna apenas a data (YYYY/DD/MM)
SELECT CURRENT_DATE 

SELECT TO_CHAR(CURRENT_DATE, 'DD/MM/YYYY')

SELECT AGE('', datanascimento) from funcionario