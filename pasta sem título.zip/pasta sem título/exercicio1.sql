/*Exercícios 1: Utilize a base de dados funciońarios*/

/*1- Inserir 4 departamentos: TI, RH, Administração e Almox.*/
--Usa-se todos os dados, para completar a linha, através do INSERT
INSERT INTO DEPARTAMENTO (coddepartamento, nome)
VALUES (01, 'TI')

--Sem se completar o "coddepartamento" o SQL entende-o como serial, ou seja, se autocompleta 
INSERT INTO DEPARTAMENTO (nome)
VALUES ('TI')
INSERT INTO DEPARTAMENTO (nome)
VALUES ('RH')
INSERT INTO DEPARTAMENTO (nome)
VALUES ('Administração')
INSERT INTO DEPARTAMENTO (nome)
VALUES ('Almox')

/*2- Insira um funcionário com nome João Matias, cpf 01243565478 e que nasceu em 28/5/1995. Ele deve trabalhar no departamento TI.*/
--Ao se inserir a data como string...
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO)
VALUES (01, 01243565478, 'João Matias', 0, '28/5/1995')

--Ao inserir a data como atributo to_date, pode se usar para outros tipos de pesquisas (recomendado)
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO)
VALUES (01, 01243565478, 'João Matias', 0, to_date('28/5/1995', DD/MM/YYYY))

--No exemplo acima faltou adiciomar o sexo, o código abaixo é a solução para completar--
UPDATE funcionario SET sexo='M'
WHERE codfuncionario=2 

/*3- Insira 3 funcionários (com dados diferentes) em cada departamento criado no exercício 1.*/
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO, sexo)
VALUES (01, 01243565479, 'Djhorivalldo Pintanel', 0, '28/5/1995', 'M')
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO, sexo)
VALUES (01, 01243565477, 'Tiago Moraes', 0, '25/6/1999', 'M')
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO, sexo)
VALUES (01, 01243565476, 'Raquel Barbosa', 0, '12/7/1996', 'F')
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO, sexo)
VALUES (02, 01243565475, 'Marcio Torres', 0, '5/8/1997', 'M')
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO, sexo)
VALUES (02, 01243565474, 'Lucía Alda', 0, '2/9/1997', 'F')
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO, sexo)
VALUES (02, 01243565473, 'Ornella Dapuzzo', 0, '11/10/1995', 'F')
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO, sexo)
VALUES (03, 01243565472, 'Aline Machado', 0, '20/11/1994', 'F')
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO, sexo)
VALUES (03, 01243565471, 'Augusto Falck', 0, '31/12/1999', 'M')
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO, sexo)
VALUES (03, 01243565470, 'Taíse Silva', 0, '13/1/2000', 'F')
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO, sexo)
VALUES (04, 01243565468, 'Carolina Velleda', 0, '24/2/1996', 'F')
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO, sexo)
VALUES (04, 01243565458, 'Daniel Baz', 0, '29/3/1993', 'M')
INSERT INTO FUNCIONARIO (coddepartamento, CPF, nome, salario, DATANASCIMENTO, sexo)
VALUES (04, 01243565448, 'Cleiva Aguiar', 0, '17/4/1990', 'F')

/*4- Aloque João Matias no P&D.*/
INSERT INTO DEPARTAMENTO (nome)
VALUES ('P&D')

--Comando para alocar um dado para outro valor, no exemplo usa-se o código do novo departamento de João Matias no SET e o seu código de funcionário no WHERE. É necessário usar, na condição, um dado ÚNICO
UPDATE FUNCIONARIO SET CODDEPARTAMENTO=5
WHERE CODFUNCIONARIO=2

/*5- Altere o nome do departamento "Almox" para "Almoxerifado".*/
UPDATE DEPARTAMENTO SET nome='Almoxerifado'
WHERE coddepartamento=3 

/*6- Em todos departamentos concatene a palavra "Depto " com o seu nome.*/
--Para concatenar usa-se "||" entre o que se deseja
UPDATE DEPARTAMENTO SET nome='Depto.' || nome

/*7- Mostre todos funcionários homens que trabalham no departamento de TI ou RH.*/
--Na condição vemos que o coddepartamento pode corresponder a dois valores diferentes, logo é mais fácil "desmembrar" a condição dada no exercício e realiza-la por partes. Primeiro selecionamos os funcionários homens e em seguida dizemos que sua nova condição pode ter valores diferentes
SELECT * from funcionario
WHERE sexo='M' and (coddepartamento = 1 or coddepartamento = 2)

/*8- Mostre apenas o nome e cpf dos funcionários com salários entre 2000 e 10000.*/
SELECT nome, cpf from funcionario
WHERE salario >= 2000 and salario <= 10000

/*9- Liste o nome e idade de todos funcionários.*/
--
SELECT nome, extract(year from age(funcionario.datanascimento))
FROM funcionario--Retorna a data (YYYY/DD/MM) e o horário atual (HH:MM:SS:mmmmmm-mm)
SELECT NOW()

--Retorna apenas a data (YYYY/DD/MM)
SELECT CURRENT_DATE 

SELECT TO_CHAR(CURRENT_DATE, 'DD/MM/YYYY')

SELECT AGE('', datanascimento) from funcionario

/*10- Mostre tod--Retorna a data (YYYY/DD/MM) e o horário atual (HH:MM:SS:mmmmmm-mm)
SELECT NOW()

--Retorna apenas a data (YYYY/DD/MM)
SELECT CURRENT_DATE 

SELECT TO_CHAR(CURRENT_DATE, 'DD/MM/YYYY')

SELECT AGE('', datanascimento) from funcionarioartamento 03.*/
SELECT * from fu--Retorna a data (YYYY/DD/MM) e o horário atual (HH:MM:SS:mmmmmm-mm)
SELECT NOW()

--Retorna apenas a data (YYYY/DD/MM)
SELECT CURRENT_DATE 

SELECT TO_CHAR(CURRENT_DATE, 'DD/MM/YYYY')

SELECT AGE('', datanascimento) from funcionario
WHERE coddeparta--Retorna a data (YYYY/DD/MM) e o horário atual (HH:MM:SS:mmmmmm-mm)
SELECT NOW()

--Retorna apenas a data (YYYY/DD/MM)
SELECT CURRENT_DATE 

SELECT TO_CHAR(CURRENT_DATE, 'DD/MM/YYYY')

SELECT AGE('', datanascimento) from funcionario
 
/*11- Exclua todos funcinários com mais de 50 anos.*/
DELETE FROM funcionario 
WHERE (extract(year from age(funcionario.datanascimento))) > 27

/*12- Faça um aumento de 10% para todas a mulheres.*/
--Forma 1: o acréscimo é o atual SOMADO à porcentagem desejada do atual
UPDATE funcionario SET salario = salario + (salario*0.1)
WHERE sexo='F' 

--Forma 2: o acréscimo é o atual multiplicado por 1.1 (calculo obtido por regra de três)
--salario--100%
--x---------10%
UPDATE funcionario SET salario = salario*1.1
WHERE sexo='F' 


--ARQUIVES--

--Retorna a data (YYYY/DD/MM) e o horário atual (HH:MM:SS:mmmmmm-mm)
SELECT NOW()

--Retorna apenas a data (YYYY/DD/MM)
SELECT CURRENT_DATE 

SELECT TO_CHAR(CURRENT_DATE, 'DD/MM/YYYY')

SELECT AGE('', datanascimento) from funcionario