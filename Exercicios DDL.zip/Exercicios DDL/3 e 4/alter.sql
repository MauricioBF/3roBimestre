ALTER TABLE "preReq" RENAME TO "preRequisito";

ALTER TABLE "Aluno" ADD COLUMN "RG_Aluno" varchar (10) NOT NULL;
ALTER TABLE "Professor" ADD COLUMN "RG_Professor" varchar (10) NOT NULL;
ALTER TABLE "Aluno" ADD CONSTRAINT "UniqueRG_Aluno" UNIQUE ("RG_Aluno");
ALTER TABLE "Professor" ADD CONSTRAINT "UniqueRG_Professor" UNIQUE ("RG_Professor");

