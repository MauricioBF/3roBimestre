CREATE TABLE "Professor"(
    "cpf" varchar (11),
    "nomeProfessor" varchar (100) NOT NULL,
    "area" varchar (150) NOT NULL,
    CONSTRAINT "ProfessorPK" PRIMARY KEY ("cpf")
);

CREATE TABLE "Curso"(
    "codCurso" int,
    "nomeCurso" varchar (100) NOT NULL, 
    "nivel" varchar (100) NOT NULL,
    CONSTRAINT "CursoPK" PRIMARY KEY ("codCurso")
);

CREATE TABLE "Aluno"(
    "matricula" int,
    "nomeAluno" varchar (100) NOT NULL, 
    "dataNasc" date NOT NULL,
    "codCurso" int NOT NULL,
    CONSTRAINT "AlunoPK" PRIMARY KEY ("matricula"),
    CONSTRAINT "AlunoFK" FOREIGN KEY ("codCurso")
        REFERENCES "Curso" ("codCurso")
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

CREATE TABLE "Disciplina"(
    "codDisciplina" int,
    "nomeDisciplina" varchar (100) NOT NULL,
    "horas" int NOT NULL,
    "creditos" int NOT NULL,
    "codCurso" int NOT NULL,
    CONSTRAINT "DisciplinaPK" PRIMARY KEY ("codDisciplina"),
    CONSTRAINT "DisciplinaFK" FOREIGN KEY ("codCurso")
        REFERENCES "Curso" ("codCurso")
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

CREATE TABLE "Turma"(
    "codTurma" int,
    "semestre" int NOT NULL,
    "ano" int NOT NULL,
    "codProfessor" int NOT NULL,
    "codDisciplina" int NOT NULL,
    CONSTRAINT "TurmaPK" PRIMARY KEY ("codTurma"),
    CONSTRAINT "TurmaProfFK" FOREIGN KEY ("codProfessor")
        REFERENCES "Professor" ("cpf")
        ON DELETE NO ACTION
        ON UPDATE CASCADE
    CONSTRAINT "TurmaDiscFK" FOREIGN KEY ("codDisciplina")
        REFERENCES "Disciplina" ("codDisciplina")
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

CREATE TABLE "preReq"(
    "codDisciplinaLiberada" int,
    "codDisciplinaRequisito" int,
    CONSTRAINT "preReqPK" PRIMARY KEY ("codDisciplinaLiberada","codDisciplinaRequisito"),
    CONSTRAINT "preReqLiberaFK" FOREIGN KEY ("codDisciplinaLiberada")
        REFERENCES "Disciplina" ("codDisciplina")
        ON DELETE NO ACTION
        ON UPDATE NO ACTION
    CONSTRAINT "preReqRequisitoFK" FOREIGN KEY ("codDisciplinaRequisito")
        REFERENCES "Disciplina" ("codDisciplina")
        ON DELETE NO ACTION 
        ON UPDATE NO ACTION
);

CREATE TABLE "AlunoTurma"(
    "codAluno" int NOT NULL,
    "codTurma" int NOT NULL,
    CONSTRAINT "AlunoTFK" FOREIGN KEY ("codAluno")
        REFERENCES "Aluno" ("matricula")
        ON DELETE CASCADE
        ON UPDATE CASCADE
    CONSTRAINT "ATurmaFK" FOREIGN KEY ("codTurma")
        REFERENCES "Turma" ("codTurma")
        ON DELETE CASCADE
        ON UPDATE CASCADE
);