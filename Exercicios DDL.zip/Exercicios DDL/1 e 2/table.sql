CREATE TABLE "Cliente" (
    "cpfCliente" varchar (11),
    "telefone" numeric NOT NULL,
    "nomeCliente" varchar (100) NOT NULL,
    CONSTRAINT "ClientePK" PRIMARY KEY ("cpfCliente")
);

CREATE TABLE "Empregado" (
    "cpfEmpregado" varchar (11),
    "nomeEmpregado" varchar (100) NOT NULL,
    "cargo" varchar (100) NOT NULL,
    CONSTRAINT "EmpregadoPK" PRIMARY KEY ("cpfEmpregado")
);

CREATE TABLE "Projeto" (
    "codProjeto" int,
    "nomeProjeto" varchar (100) NOT NULL,
    "descricao" varchar (100) NOT NULL,
    "preco" numeric NOT NULL,
    "dtFim" date,
    "dtEstimado" date NOT NULL,
    "dtSolicitacao" date NOT NULL,
    "Cliente_cpf" varchar (11) NOT NULL,
    "Gerente_cpf" varchar (11) NOT NULL,
    CONSTRAINT "ProjetoPK" PRIMARY KEY ("codProjeto"),
    CONSTRAINT "ProjClienteFK" FOREIGN KEY ("Cliente_cpf")
        REFERENCES "Cliente" ("cpfCliente")
        ON DELETE NO ACTION
        ON UPDATE CASCADE,
    CONSTRAINT "ProjGerenteFK" FOREIGN KEY ("Gerente_cpf")
        REFERENCES "Empregado" ("cpfEmpregado")
        ON DELETE NO ACTION
        ON UPDATE CASCADE
);

CREATE TABLE "projEmp" (
    "Empregado_cpf" varchar (11),
    "codProjeto" varchar (11),
    "hrTrab" timestamp,
    CONSTRAINT "ProjEmpPK" PRIMARY KEY ("Empregado_cpf", "codProjeto"),
    CONSTRAINT "EmpFK" FOREIGN KEY ("Empregado_cpf")
        REFERENCES "Empregado" ("cpfEmpregado")
        ON DELETE NO ACTION
        ON UPDATE CASCADE,
    CONSTRAINT "ProjFK" FOREIGN KEY ("codProjeto")
        REFERENCES "Projeto" ("codProjeto")
        ON DELETE NO ACTION
        ON UPDATE CASCADE
);
