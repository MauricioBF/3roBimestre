ALTER TABLE "Empregado" RENAME TO "Empregados";

ALTER TABLE "Cliente" ADD COLUMN "RG" varchar (10) NOT NULL;

ALTER TABLE "Projeto" ALTER COLUMN "preco"
TYPE numeric (12,2);

ALTER TABLE "Cliente" ADD CONSTRAINT
    “uniqueRG” UNIQUE ("RG");

CREATE SEQUENCE "ProjSequence";
ALTER TABLE "Projeto" ALTER COLUMN "codProjeto" SET DEFAULT nextval('"ProjSequence"');