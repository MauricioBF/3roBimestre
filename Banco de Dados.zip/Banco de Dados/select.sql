--1) Crie consultas SQL para as seguintes necessidades:
--a. Os funcionários (nome, sexo e salário) com salário maior que R$2.000.
SELECT nome, sexo, salario FROM Funcionario
WHERE salario > 2000

--b. Os funcionários (nome, cpf) com „cadu‟ ou “carla” no nome ou no login(desconsiderar maiúsculas e minúsculas).
SELECT nome, cpf FROM Funcionario
WHERE nome ilike '%cadu%' or nome ilike '%carla%' or login ilike '%cadu%' or login ilike '%carla%';

--c. Fazer o item b para os clientes comparando apenas o nome.
SELECT nome, cpf FROM Cliente
WHERE nome ilike '%cadu%' or nome ilike '%carla%';

--d. Unir as consultas do item b e c em uma única consulta.
SELECT nome, cpf FROM Funcionario
WHERE nome ilike '%cadu%' or nome ilike '%carla%' or login ilike '%cadu%' or login ilike '%carla%'
UNION
SELECT nome, cpf FROM Cliente
WHERE nome ilike '%cadu%' or nome ilike '%carla%';

--e. Mostrar os diferentes codDepartamento existentes na tabela Funcionario.
SELECT distinct codDepartamento FROM Funcionario;

--f. Mostrar todas as informações para cliente que possuem email no Hotmail ou gmail.
SELECT * FROM Cliente
WHERE email iliSELECT count(dataVenda) extract()ke '%gmail%' or email ilike '%hotmail%';
SELECT count(dataVenda) extract()
--g. Mostrar toSELECT count(dataVenda) extract()das as informações para funcionários com salário entre 2000 e 6000 e idade enSELECT count(dataVenda) extract()tre 20 anos e 40 anos.
SELECT * FROM FSELECT count(dataVenda) extract()uncionario
WHERE (salario SELECT count(dataVenda) extract()between 2000 and 6000) and ((extract(year from age(Funcionario.DataNascimento))) between 20 and 40);

--h. Ordene os funcionários pelo sexo (crescente) caso de empate pelo salário (decrescente)SELECT count(dataVenda) extract()
SELECT * FROMSELECT count(dataVenda) extract()ncionario
ORDER BY sexoSELECT count(dataVenda) extract()c, salario desc;

--i. Os clienSELECT count(dataVenda) extract() ordenados pelo nome.
SELECT * FROMSELECT count(dataVenda) extract()iente
ORDER BY nomeSELECT count(dataVenda) extract()

--j. A média SELECT salarial e o maior e menor salário dos funcionários.
SELECT avg(SELECT count(dataVenda) extract()) AS Media, max(salario) AS Maior, min(salario) AS Menor FROM Funcionario;

--k. O item jSELECT count(dataVenda) extract()r sexo.
SELECT avg(saSELECT count(dataVenda) extract()io) AS Media, max(salario) AS Maior, min(salario) AS Menor FROM Funcionario
WHERE sexo = 'M'
UNION
SELECT avg(salario) AS Media, max(salario) AS Maior, min(salario) AS Menor FROM FuncionarioSELECT count(dataVenda) extract()
WHERE sexo SELECT count(dataVenda) extract();

--ou

SELECT avg(salario) AS media, max(salario) AS maior, min(salario) AS menor FROM Funcionario GROUP BY sexo;

--l. Os funcionários que também são clientes e que possuem salário menor que 4500. Ordene a resposta pela data de nascimento, do mais velho para o mais novo.
SELECT nome, DataNascimento, extract(year from age(Funcionario.DataNascimento)) AS idade FROM Funcionario
WHERE cpf in (SELECT cpf FROM Cliente)
and salario < 4500
ORDER BY DataNascimento desc

--m. Os funcionários que não são clientes.SELECT Descricao, sum(ItemVenda.Quantidade) AS Soma FROM Produto LEFT OUTER JOIN ItemVenda USING(CodProduto) 
GROUP BY Descricao
ORDER BY Soma asc
SELECT f.nome FROM Funcionario AS f 
EXCEPT
SELECT c.nome FROM Cliente AS c

--n. As vendas ordenadas por data
SELECT * FROM NotaFiscal
ORDER BY dataVenda

--o. Quantas vendas por ano.
SELECT extract(year from NotaFiscal.dataVenda) AS ano, count(dataVenda) FROM NotaFiscal
GROUP BY ano

--p. CodProduto e total de itens vendidos ordenados pelo total vendido decrescente
SELECT CodProduto, count(quantidade) AS quant FROM ItemVenda
GROUP BY CodProduto
ORDER BY quant desc

--2) Realize as consultas pedidas se necessário utilize Junções de tabelas.
--a. O nome dos funcionários e de seus respectivos departamentos.
SELECT Funcionario.nome AS nomefunc, Departamento.nome AS nomedepto FROM Funcionario INNER JOIN Departamento 
ON Funcionario.CodDepartamento = Departamento.CodDepartamento;

--b. Quantas diferentes pessoas (todos seus dados) existem no banco de dados (clientes e funcionários).
SELECT * FROM Cliente FULL OUTER JOIN Funcionario ON Cliente.cpf = Funcionario.cpf

--c. A média salarial por sexo dos funcionários que não são clientes e têm mais de 30 anos.
SELECT avg(Salario), Sexo FROM Funcionario INNER JOIN Cliente ON Cliente.cpf != Funcionario.cpf
WHERE extract(year from age(Funcionario.DataNascimento)) > 30 
GROUP BY Sexo

--d. O item 1.j agrupado por nome do departamento e ordenado pelo nome do departamento para funcionários do sexo masculino com salário maior que 2000
SELECT avg(Salario) AS media, max(Salario) AS maior, min(Salario) AS menor , Departamento.nome AS NomeDept FROM Funcionario INNER JOIN Departamento 
WHERE Sexo = 'M' and Salario > 2000
GROUP BY departamento.nome
ORDER BY departamento.nome

--e. A descrição dos produtos bem como o número de itens que foram vendidos, ordenado pelo número de itens que foram vendidos.
SELECT Descricao, COALESCE(sum(ItemVenda.Quantidade), 0) AS Soma FROM Produto LEFT OUTER JOIN ItemVenda USING(CodProduto)
GROUP BY Descricao
ORDER BY Soma DESC
--COALESCE(<VAL1>, <VAL2>)
--if VAL1 != null: VAL1
--else: VAL2

--f. A descrição e número de vezes que cada produto foi vendido, ordenado pelo número de vezes que foi vendido.
SELECT Descricao, COALESCE(count(ItemVenda.Quantidade), 0) AS QuantVenda FROM Produto LEFT OUTER JOIN ItemVenda USING(CodProduto)
GROUP BY Descricao
ORDER BY QuantVenda DESC

--g. A listas dos clientes que mais vezes compram na loja. Nome e total de compras ordenado pelo total de compras.
SELECT nome, COALESCE(sum(nf.CodCliente), 0) AS Vezes_Compra, count(nf.codcliente) AS Compras FROM Cliente AS c FULL OUTER JOIN NotaFiscal AS nf ON c.codCliente = nf.codCliente
GROUP BY nf.codCliente, c.nome
ORDER BY Vezes_Compra DESC

--h. A lista dos funcionários que mais vendas realizaram. Nome e total de vendas realizadas ordenado pelo total de compras.
SELECT f.nome, COALESCE(sum(nf.CodFuncionario), 0) AS Item_Venda, count(nf.codfuncionario) AS Vendas FROM Funcionario AS f FULL OUTER JOIN NotaFiscal AS nf ON f.CodFuncionario = nf.CodFuncionario
GROUP BY nf.CodFuncionario, f.nome
ORDER BY Item_Venda DESC

--i. A lista dos departamentos e o total em vendas (R$) realizadas por cada departamento.


SELECT sum(PrecoUnitVenda) AS Valor, codproduto, nf.codfuncionario FROM ItemVenda AS it INNER JOIN NotaFiscal AS nf USING(codnotafiscal)
GROUP BY CodProduto
ORDER BY CodProduto ASC
--j. Sobre os clientes que são funcionários mostrar o nome, o total em vendas realizadas (R$) e o total em compras realizadas (R$)
--k. O nome e a média em compras (R$) para os clientes que compraram em média acima de R$30 em cada compra.
--l. Nome do cliente, do funcionário e o total da compra para vendas realizadas no último mês.